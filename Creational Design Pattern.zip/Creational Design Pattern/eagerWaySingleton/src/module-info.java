module eagerWaySingleton {
}