module Prototype {
}